import unittest

from translator import __french_to_english__, __english_to_french__

class TestFrench(unittest.TestCase): 
    def test1(self): 
        self.assertEqual(__french_to_english__('Bonjour'), 'Hi')
    def test2(self):
        self.assertNotEqual(__french_to_english__('Bonjour'), 'Bye')

        
class TestEnglish(unittest.TestCase): 
    def test1(self): 
        self.assertEqual(__english_to_french__('Hello'), 'Bonjour')
    def test2(self):
        self.assertNotEqual(__english_to_french__('Bye'), 'Bonjour')

unittest.main()
