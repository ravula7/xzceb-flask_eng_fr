from deep_translator import MyMemoryTranslator

def __english_to_french__(english_text):
    french_text = MyMemoryTranslator(source='en-US',target='fr-FR').translate(english_text)
    return french_text

def __french_to_english__(french_text):
    english_text = MyMemoryTranslator(source='fr-FR',target='en-US').translate(french_text)
    return english_text
